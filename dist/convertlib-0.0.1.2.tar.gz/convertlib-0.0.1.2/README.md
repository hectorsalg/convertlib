convertlib
========

### Esse é um pacote que converte arquivos de diversas extensões.


## Instalação
    pip install convertlib

## Uso
```
import convertlib as cv
path = "path/to/file.extension"
converter = cv.convertlib(path)
converter.docx2pdf()
```